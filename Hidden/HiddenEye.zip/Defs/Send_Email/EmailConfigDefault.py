gmail_account = "GMAILACCOUNT"
gmail_password = "GMAILPASSWORD"
recipient_email = "RECIPIENTEMAIL"
