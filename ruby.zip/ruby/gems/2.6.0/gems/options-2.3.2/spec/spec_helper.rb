require 'rubygems'
require 'spec'
require 'pathname'
require 'pp'

$LOAD_PATH.unshift Pathname(__FILE__).dirname + "../lib"

