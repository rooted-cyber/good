module ChildProcess
  VERSION = '3.0.0'
end
