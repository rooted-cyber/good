# coding: utf-8

class HighLine
  # The version of the installed library.
  VERSION = "2.0.3".freeze
end
