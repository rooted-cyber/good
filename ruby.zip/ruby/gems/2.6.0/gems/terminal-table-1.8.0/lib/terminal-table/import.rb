require 'terminal-table' #required as some people require this file directly from their Gemfiles

include Terminal::Table::TableHelper
