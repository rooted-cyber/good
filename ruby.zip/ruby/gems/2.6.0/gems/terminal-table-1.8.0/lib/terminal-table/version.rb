module Terminal
  class Table
    VERSION = '1.8.0'
  end
end
